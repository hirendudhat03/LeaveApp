export default {
    //Bold
    Bold: 'Ubuntu-Bold',
    BoldItalic: 'Ubuntu-BoldItalic',
    //Light
    Light: 'Ubuntu-Light',
    LightItalic: 'Ubuntu-LightItalic',
    //Medium
    Medium: 'Ubuntu-Medium',
    MediumItalic: 'Ubuntu-MediumItalic',
    //Regular
    Regular: 'Ubuntu-Regular',
    RegularItalic: 'Ubuntu-RegularItalic',
  };
  