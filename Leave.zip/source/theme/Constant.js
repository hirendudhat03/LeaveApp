export default {
    baseURL : 'http://192.168.1.114/adminlite/api?_api=',
    sessId : 'sessId',
    email : 'email',
    firstname : 'firstname',
    lastname : 'lastname',
  };
  