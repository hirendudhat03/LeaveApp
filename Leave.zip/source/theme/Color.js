export default {
    Colorwhite: '#FBFBFB',
    ColorBlack: '#000000',
    ColorOrange:'#FD7510',
    Gray:'#808080',
    InputBG:'#EBEBEB',
    TabBG:'#265F9C',
    TabActive:'#347AC5',
    DrawerBG:'#474747',
    ColorRed:'#ED3F36',
    ColorTitle:'#222222',
    ColorSubText:'#808080',
    ColorShadow:'#B2B2B2',
    LightGreen:'#38B34B',
  };
  